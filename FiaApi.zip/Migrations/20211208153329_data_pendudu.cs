﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace FiaApi.Migrations
{
    public partial class data_pendudu : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tabel_penduduk",
                columns: table => new
                {
                    nik = table.Column<string>(type: "varchar(16)", nullable: false),
                    nama = table.Column<string>(type: "varchar(150)", nullable: true),
                    alamat = table.Column<string>(type: "varchar(200)", nullable: true),
                    usia = table.Column<string>(type: "varchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tabel_penduduk", x => x.nik);
                });

            migrationBuilder.CreateTable(
                name: "tabel_penghasilan",
                columns: table => new
                {
                    id_pekerjaan = table.Column<string>(type: "varchar(5)", nullable: false),
                    nik = table.Column<string>(type: "varchar(16)", nullable: true),
                    gaji = table.Column<string>(type: "varchar(2000)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tabel_penghasilan", x => x.id_pekerjaan);
                    table.ForeignKey(
                        name: "FK_tabel_penghasilan_tabel_penduduk_nik",
                        column: x => x.nik,
                        principalTable: "tabel_penduduk",
                        principalColumn: "nik",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tabel_pekerjaan",
                columns: table => new
                {
                    id_pekerjaan = table.Column<string>(type: "varchar(5)", nullable: false),
                    pekerjaan = table.Column<string>(type: "varchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tabel_pekerjaan", x => x.id_pekerjaan);
                    table.ForeignKey(
                        name: "FK_tabel_pekerjaan_tabel_penghasilan_id_pekerjaan",
                        column: x => x.id_pekerjaan,
                        principalTable: "tabel_penghasilan",
                        principalColumn: "id_pekerjaan",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tabel_penghasilan_nik",
                table: "tabel_penghasilan",
                column: "nik");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tabel_pekerjaan");

            migrationBuilder.DropTable(
                name: "tabel_penghasilan");

            migrationBuilder.DropTable(
                name: "tabel_penduduk");
        }
    }
}
