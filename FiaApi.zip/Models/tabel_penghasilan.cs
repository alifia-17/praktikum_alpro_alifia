using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FiaApi.Models
{
    public class tabel_penghasilan
    {
        [Key]
        [Column(TypeName = "varchar(5)")]
        public string id_pekerjaan { get; set; }
        [Column(TypeName = "varchar(16)")]
        public string nik { get; set; }

        [Column(TypeName = "varchar(2000)")]
        public string gaji { get; set; }

        [ForeignKey("id_pekerjaan")]
        public ICollection <tabel_pekerjaan> tabel_pekerjaan { get; set; }
    }
}