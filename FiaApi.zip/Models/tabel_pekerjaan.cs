using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FiaApi.Models
{
    public class tabel_pekerjaan
    {
        [Key]
        [Column(TypeName ="varchar(5)")]
        public string id_pekerjaan { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string pekerjaan { get; set; }
    }
}