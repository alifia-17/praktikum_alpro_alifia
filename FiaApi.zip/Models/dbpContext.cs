using Microsoft.EntityFrameworkCore;

namespace FiaApi.Models
{
    public class dbpContext : DbContext
    {
        public dbpContext(DbContextOptions<dbpContext> options)
            : base(options)
        {
        }
        public DbSet<tabel_pekerjaan> tabel_pekerjaan { get; set; }
        public DbSet<tabel_penduduk> tabel_penduduk { get; set; }
        public DbSet<tabel_penghasilan> tabel_penghasilan { get; set; }
    }
}