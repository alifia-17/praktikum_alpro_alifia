using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FiaApi.Models
{
    public class tabel_penduduk
    {
        [Key]
        [Column(TypeName = "varchar(16)")]
        public string nik { get; set; }

        [Column(TypeName = "varchar(150)")]
        public string nama { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string alamat { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string usia { get; set; }

        [ForeignKey("nik")]
        public ICollection <tabel_penghasilan> tabel_penghasilan { get; set; }
    }
}