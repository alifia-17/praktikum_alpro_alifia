using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FiaApi.Models;

namespace FiaApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tabel_pendudukController : ControllerBase
    {
        private readonly dbpContext _context;

        public tabel_pendudukController(dbpContext context)
        {
            _context = context;
        }

        // GET: api/tabel_penduduk
        [HttpGet]
        public async Task<ActionResult<IEnumerable<tabel_penduduk>>> Gettabel_penduduk()
        {
            return await _context.tabel_penduduk.ToListAsync();
        }

        // GET: api/tabel_penduduk/5
        [HttpGet("{id}")]
        public async Task<ActionResult<tabel_penduduk>> Gettabel_penduduk(string id)
        {
            var tabel_penduduk = await _context.tabel_penduduk.FindAsync(id);

            if (tabel_penduduk == null)
            {
                return NotFound();
            }

            return tabel_penduduk;
        }

        // PUT: api/tabel_penduduk/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Puttabel_penduduk(string id, tabel_penduduk tabel_penduduk)
        {
            if (id != tabel_penduduk.nik)
            {
                return BadRequest();
            }

            _context.Entry(tabel_penduduk).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tabel_pendudukExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/tabel_penduduk
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<tabel_penduduk>> Posttabel_penduduk(tabel_penduduk tabel_penduduk)
        {
            _context.tabel_penduduk.Add(tabel_penduduk);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (tabel_pendudukExists(tabel_penduduk.nik))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("Gettabel_penduduk", new { id = tabel_penduduk.nik }, tabel_penduduk);
        }

        // DELETE: api/tabel_penduduk/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Deletetabel_penduduk(string id)
        {
            var tabel_penduduk = await _context.tabel_penduduk.FindAsync(id);
            if (tabel_penduduk == null)
            {
                return NotFound();
            }

            _context.tabel_penduduk.Remove(tabel_penduduk);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool tabel_pendudukExists(string id)
        {
            return _context.tabel_penduduk.Any(e => e.nik == id);
        }
    }
}
